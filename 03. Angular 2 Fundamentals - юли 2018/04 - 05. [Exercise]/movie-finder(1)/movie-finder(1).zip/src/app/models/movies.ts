// import { Movie } from "./movie";

export interface Movies {
    results: Array<any>;
}