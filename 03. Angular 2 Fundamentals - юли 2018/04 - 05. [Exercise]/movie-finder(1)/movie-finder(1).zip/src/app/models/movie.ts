export interface Movie {
    id: string;
    poster_path: string;
    title: string;
    release_date: string;
}